<!DOCTYPE html>
<html>
	<head>
		<title>Projeto</title>
		<link href="https://fonts.googleapis.com/css?family=Oswald" rel="stylesheet">
		<link href="css/style.css" type="text/css" rel="stylesheet">
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
		<meta http-equiv="refresh" content="15">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
	</head>

	<body>
		<?php require_once 'process.php'; ?>
		<header>
			<div class="container">
				<div class="logo">LOGO</div><!--logo-->
				<div class="titulo">Client-Side</div>
				<div class="clear"></div>
			</div><!--container-->
			
		</header>
		
		<section class="banner">
			<p>Local destinado a imagem dos carros para locação</p>
			<h1>Veículos</h1>

			<div class="carros">
				<?php 

				$mysqli = new mysqli('localhost', 'root', '','crud') or die(mysqli_error($mysqli));
				$result = $mysqli->query("SELECT * FROM base") or die($mysqli->error);
				?>

				<div class="row justify-content-center">
					<table class="table">
						<thead>
							<tr>
								<th>Código</th>
								<th>Marca</th>
								<th>Modelo</th>
								<th>Tipo</th>
								<th>Status</th>
							</tr>
						</thead>
						<?php
							while ($row = $result->fetch_assoc()): ?>
								<tr>
									<td><?php echo $row['id']; ?></td>
									<td><?php echo $row['modelo']; ?></td>
									<td><?php echo $row['marca']; ?></td>
									<td><?php echo $row['tipo']; ?></td>
									<td><?php echo $row['stat']; ?></td>
									<td>
										<a href="process.php?aluga=<?php echo $row['id'] ?>" class="btn btn-info">Alugar Carro</a>
									</td>
								</tr>
							<?php endwhile; ?>
					</table>
				</div>
			</div>
		</section>

		<section class="sobre">
			<div class="sob">
				<h1>História</h1>
				<p>
				"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
				"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
				"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
				</p>
			</div>
			
		</section>
		<section class="vendas">
			
		</section>
		<footer></footer>
	</body>
</html>